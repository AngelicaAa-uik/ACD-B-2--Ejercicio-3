
package pruebaparalelo;
import java.util.Arrays;
public class PruebaParalelo {
    //Clase Prueba/Ejecutor. 
    public static void main(String[] args) {
        //Creacion de los objetos de tipo Estudiante. 
        Estudiante est1 = new Estudiante("Javier Marlow", 9.1, 8.3);
        Estudiante est2 = new Estudiante("Enrique Piniones", 7, 8);
        Estudiante est3 = new Estudiante("Marco Juarez", 6.5, 7);
        Estudiante est4 = new Estudiante("Mikaela Perez", 8.5, 10);
        //Inicializacion del arreglo bidimensional con los objetos de tipo Estudiante, en sus respectivas filas y columnas. 
        Estudiante estudiantes[][] = {
            {est1, est2}, 
            {est3, est4}
        };
        /***
         * Tambien podemos inicializar el arreglo y declarar los objetos, inicializandolos directamente por medio del new.
         * De la siguiente forma: 
         * Estudiante estudiantes[][]={{new Estudiante("Javier Marlow", 9.1, 8.3), new Estudiante("Enrique Piñones", 7, 8)},
         * {new Estudiante("Marco Juarez", 6.5, 7), new Estudiante("Mikaela Perez", 8.5, 10)}};
        */
        //Creacion de los dos objetos Paralelo. 
        Paralelo paralelo1 = new Paralelo('A', estudiantes, 0);
        Paralelo paralelo2 = new Paralelo('B', estudiantes, 1);
        //for que nos permite recorrer nuestro arreglo para calcular la nota parcial de cada estudiante. 
        for (Estudiante[] estudiante1 : estudiantes) {
            for (Estudiante estudiante : estudiante1) {
                estudiante.calcularNotaParcial();
            }
        }
        System.out.println(paralelo1);
        System.out.println(paralelo2);
        //Declaracion de variables. 
        double promedioTotal;
        double suma = 0;
        int numeroEst = 0;
        //for para calcular el promedio Total de todos los paralelos.
        for (Estudiante[] paralelo : estudiantes) {
            for (Estudiante estudiante : paralelo) {
                suma += estudiante.notaParcial;
                numeroEst++;
            }
        }
        promedioTotal = suma / numeroEst;
        System.out.println("Promedio de todos los paralelos: " + promedioTotal);
    }
}
class Paralelo {
    //Declaracion de datos o atributos.
    public char nomParalelo;
    public Estudiante estudiantes[][];
    public int fila;// Establecer la fila que corresponde, permitiendonos guardar el índice de la fila.
    //Constructor.
    public Paralelo(char nomParalelo, Estudiante[][] estudiantes, int fila) {
        this.nomParalelo = nomParalelo;
        this.estudiantes = estudiantes;
        this.fila = fila;
    }
    /***
     * Metodo toString modificado, para que nos permita imprimir de forma correcta 
     * los objetos del arreglo perteneciente a cada paralelo por medio 
     * del ingreso del numero del subindice de la fila. 
    */
    @Override
    public String toString() {
        String result = "Paralelo" + nomParalelo + ":\n"; 
        for (Estudiante estudiante : estudiantes[fila]) {
            result += nomParalelo + "\t" + estudiante.toString() + "\n";
        }
        return result;
    }
}
class Estudiante {
    //Declaracion de los atributos o datos de la clase. 
    public String nomEstudiante;
    public double nota1;
    public double nota2;
    public double notaParcial;
    //Constructor.
    public Estudiante(String nomEstudiante, double nota1, double nota2) {
        this.nomEstudiante = nomEstudiante;
        this.nota1 = nota1;
        this.nota2 = nota2;
    }
    //Metodo toString.
    @Override
    public String toString() {
        return "Estudiante{" + "nomEstudiante=" + nomEstudiante + ", nota1=" + nota1 + ", nota2=" + nota2 + ", notaParcial=" + notaParcial + '}';
    }
    //Metodo para calcular la nota parcial.  
    public void calcularNotaParcial(){
        this.notaParcial = (this.nota1 + this.nota2)/2;
    }
}

